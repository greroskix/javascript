let isEven = (num) => {
    return num % 2 === 0
}

console.log(isEven(4))