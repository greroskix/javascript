//Soma:
let soma = (a, b) => `Adição: 7+7 = ${a+b}`

//Subtração:
let sub = (a, b) => `Subtração: 14-7 = ${a-b}`

//Multiplicação:
let mult = (a, b) => `Multiplicação: 7*7 = ${a*b}`

//Divisão
let div = (a, b) => `Divisão: 49/14 = ${a/b}`

console.log(soma(7, 7))
console.log(sub(14, 7))
console.log(mult(7, 7))
console.log(div(49, 14))