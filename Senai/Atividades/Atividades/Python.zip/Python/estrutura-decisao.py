# Simples

a = True
b = False

if(a or b):
    print("O resulado foi?")
else:
    print("Ixi")
print(a or b)