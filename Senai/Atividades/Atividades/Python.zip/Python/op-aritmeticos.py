a = 10
b = 3

# Div:
res = a // b
print(res)

# Mod:
res = a % b
print(res)

# Potência
res = a**b
print(res)