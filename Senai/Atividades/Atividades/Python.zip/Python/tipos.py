# Fazer comentários

# Tipo Int:
variavel = 10
print(variavel)
print(type(variavel))

# Tipo String:
variavel = "Oi"
print(variavel)
print(type(variavel))

# Tipo Float:
variavel = 2.2
print(variavel)
print(type(variavel))

# Tipo Boolean:
variavel = True 
variavel = False
print(variavel)
print(type(variavel))
