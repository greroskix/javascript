# Com mensagem para o usuário:
numero = input("Digite um número: ")
print(numero)

# Sem mensagem para o usuário:
numero = input()
print(numero)