# Igual ==

a = 5
b = 2
res = (a == b)
print(res)

# Diferente != 

res = (a != b)
print(res)

# Outros... >, <, >=, <=
