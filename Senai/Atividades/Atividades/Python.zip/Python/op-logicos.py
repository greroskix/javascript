# E - And - Ambas as expressões DEVEM ser True para dar True

a = True
b = False
res = a and b
print(res)

# Ou - Or - Pelo menos uma das expressões deve ser True para dar True

res= a or b
print(res)

# Não - Not - Inverter o valor booleano da expressão

res = not res 
print(res)